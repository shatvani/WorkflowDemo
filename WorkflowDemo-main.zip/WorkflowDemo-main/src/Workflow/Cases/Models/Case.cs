﻿using Shared.DDD;

namespace Workflow.Cases.Models;

public class Case : AuditableAggregate<Guid>
{
}
