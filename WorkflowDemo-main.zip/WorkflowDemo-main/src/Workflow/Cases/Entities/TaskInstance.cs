﻿using Shared.DDD;

namespace Workflow.Cases.Entities;

public class TaskInstance : Entity<Guid>
{
}
